
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ednutlab',
  applicationName: 'cashlypay',
  appUid: 'YRngcWtjmlGNHYjbNV',
  orgUid: '5ffc25dd-1e7c-48f2-9cf5-4f9427eb4b02',
  deploymentUid: '78a4fdb7-245e-4c41-b493-f01948516845',
  serviceName: 'cashlypay',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'cashlypay-dev-web', timeout: 30 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}